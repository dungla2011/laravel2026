<?php

class RemoteFile1 extends \Sabre\DAV\File {
    private $path;

    function __construct($path) {
        $this->path = $path;
    }

    function getName() {
        return basename($this->path);
    }

    function get() {
        return "111";
        // Replace this with a call to your API
//        return file_get_contents($this->path);
    }

    function getSize() {
        // Replace this with a call to your API
        return 111;
//        return filesize($this->path);
    }
}

class RemoteDirectory1 extends \Sabre\DAV\Collection {
    private $path;
    private $fid;

    function __construct($path) {
        $this->path = $path;
        if($path == '/')
            $this->fid = 0;
    }

    function getName() {
        return basename($this->path);
    }

    function getChildren() {

        $fold= new \App\Models\FolderFile();
        if($fold instanceof \App\Models\ModelGlxBase);

        // Replace this with a call to your API
        $children = [];

        $mm = $fold->getChildren(1);

        foreach ($mm AS $obj){

            if($obj->isFile){
                $dir = new RemoteDirectory($this->path . '/' . $obj->name);
                $children[] = $dir;
            }
            else {
                $file = new RemoteFile($this->path . '/' . $obj->name);
                $children[] = $file;
            }
//            $children[] = $obj->isFile
//                ? new RemoteDirectory($this->path . '/' . $obj->name)
//                : new RemoteFile($this->path . '/' . $obj->name);
        }

//        foreach (scandir($this->path) as $file) {
//            if ($file === '.' || $file === '..') continue;
//            $children[] = is_dir($this->path . '/' . $file)
//                ? new RemoteDirectory($this->path . '/' . $file)
//                : new RemoteFile($this->path . '/' . $file);
//        }



        return $children;
    }

    function childExists($name) {
        // Replace this with a call to your API
        return 1;//file_exists($this->path . '/' . $name);
    }

    function getChild($name) {
        // Replace this with a call to your API
        $path = $this->path . '/' . $name;
        return is_dir($path)
            ? new RemoteDirectory($path)
            : new RemoteFile($path);
    }

    function getSize() {
        // Replace this with a call to your API
        return 222;
//        return filesize($this->path);
    }
}
