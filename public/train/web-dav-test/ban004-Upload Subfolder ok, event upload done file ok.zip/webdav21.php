<?php

function ol3($str)
{
    $bname = basename(__FILE__);
    file_put_contents("/var/glx/weblog/$bname.log", date("Y-m-d H:i:s") ." # ". $str . "\n", FILE_APPEND);
}

$sr = serialize($_SERVER);
//if(str_contains($sr, 'Zscaler'))
//    ol3(" \n\n SERVER = " . serialize($_SERVER) . "\n\n");

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', '/var/glx/weblog/test123.log');

$_SERVER['HTTP_HOST'] = $_SERVER['SERVER_NAME'] = 'cloud1.mytree.vn';

$bname = basename(__FILE__);

require '/var/www/html/vendor/autoload.php';
require 'lib-webdav.php';
$app = require_once '/var/www/html/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
$response = $kernel->handle( $request = Illuminate\Http\Request::capture());
//////////////////////////////// Kết thúc đoạn Init Framework Laravel///

$uid = 1;
$publicDir = '/share'; // WebDAV Bao loi
$publicDir = "/var/www/html/public/images/tmp"; // WebDAV  OK
$publicDir = "/"; // WebDAV  OK
//$publicDir = "/share-web-dav";
//$server = new \Sabre\DAV\Server(new \Sabre\DAV\FS\Directory($publicDir));
//$server = new \Sabre\DAV\Server(new RemoteDirectory($publicDir, 1));
$server = new Server2(new RemoteDirectory($publicDir, $uid));
$server->uid = $uid;
$server->tree->uid = $uid;

$server->setBaseUri('/train/web-dav-test/' . $bname);


// Add the browser plugin
$browser = new \Sabre\DAV\Browser\Plugin();
$server->addPlugin($browser);
$server->addPlugin(new CustomPutPlugin());
$server->addPlugin(new CapturePutPlugin());
$server->exec();

