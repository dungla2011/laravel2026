<?php


use Sabre\DAV\CorePlugin;
use Sabre\DAV\Exception;
use Sabre\DAV\FS\File;
use Sabre\DAV\IMoveTarget;
use Sabre\DAV\INode;
use Sabre\DAV\SimpleCollection;
use Sabre\DAV\Tree;
use Psr\Log\LoggerAwareInterface;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;
use Sabre\Event\EmitterInterface;
use Sabre\Event\WildcardEmitterTrait;
use Sabre\HTTP;
use Sabre\HTTP\RequestInterface;
use Sabre\HTTP\ResponseInterface;
use Sabre\Uri;
use Sabre\Xml\Writer;
use Sabre\DAV\Xml;
use Sabre\DAV;

class Server2 extends \Sabre\DAV\Server {

    public $uid = 0;
    public function __construct($treeOrNode = null, HTTP\Sapi $sapi = null)
    {
        if ($treeOrNode instanceof Tree2) {
            $this->tree = $treeOrNode;
        } elseif ($treeOrNode instanceof INode) {
            $this->tree = new Tree2($treeOrNode);
        } elseif (is_array($treeOrNode)) {
            $root = new SimpleCollection('root', $treeOrNode);
            $this->tree = new Tree2($root);
        } elseif (is_null($treeOrNode)) {
            $root = new SimpleCollection('root');
            $this->tree = new Tree2($root);
        } else {
            throw new Exception('Invalid argument passed to constructor. Argument must either be an instance of Sabre\\DAV\\Tree, Sabre\\DAV\\INode, an array or null');
        }

        $this->xml = new Xml\Service();
        $this->sapi = $sapi ?? new HTTP\Sapi();
        $this->httpResponse = new HTTP\Response();
        $this->httpRequest = $this->sapi->getRequest();
        $this->addPlugin(new CorePlugin());
    }
}

class Tree2 extends \Sabre\DAV\Tree{
    public $uid;
    /**
     * Deletes a node from the tree.
     *
     * @param string $path
     */
    public function delete($path)
    {
        ol3("Tree2 Delete0 $path");

//        return;

        $sid = \App\Models\SiteMng::getSiteId();
        $path = trim($path);
//        echo "<br/>\n PATHx = $path";
        $uid = $this->uid;

        $path1 = "/share/dav/siteid_$sid/$uid/". $path;
//        die("DELETE.....xxx: $path");

        ol3("Tree2 Delete1 $path1");

        if(is_file($path1)){
            $fid = intval(file_get_contents($path1.'.fid'));
            \App\Models\FileUpload::find($fid)?->delete();
        }
        unlink($path1);
//
//        parent::delete($path);
    }

    public function move($sourcePath, $destinationPath){

        ol3("MOVEx: $sourcePath -> $destinationPath ");
        $sid = \App\Models\SiteMng::getSiteId();
        $sourcePath = trim($sourcePath);
        $destinationPath = trim($destinationPath);

//        echo "<br/>\n PATHx = $path";
        $uid = $this->uid;

        $sourcePath = "/share/dav/siteid_$sid/$uid/". $sourcePath;
        $destinationPath = "/share/dav/siteid_$sid/$uid/". $destinationPath;

        ol3("MOVEx2: $sourcePath -> $destinationPath ");

        //Doi ten
        if(dirname($sourcePath) == dirname($destinationPath)){
            rename($sourcePath, $destinationPath);
            //Nếu là folder, sẽ có id:
            if(file_exists($sourcePath.".id")){
                $fid = intval(file_get_contents($sourcePath.'.id'));
                if($folder = \App\Models\FolderFile::find($fid)){
                    $folder->name = basename($destinationPath);
                    $folder->save();
                    rename($sourcePath.".id", $destinationPath.'.id');
                }
            }
            else{
                $fid = intval(file_get_contents($destinationPath.'.fid'));
                if($file = \App\Models\FileUpload::find($fid)){
                    $file->name = basename($destinationPath);
                    $file->save();
                }
            }
        }

//
//
//        die("MOVEx: $sourcePath -> $destinationPath ");
//
//        parent::move($sourcePath, $destinationPath);
    }
}

class RemoteFile extends \Sabre\DAV\FS\File {
    protected $path;

    function __construct($path) {
        $this->path = $path;
    }

    function getName() {
        return basename($this->path);
    }

    function get() {

        ol3("GET FILE: $this->path");

        if(file_exists($this->path) && filesize($this->path) < 20){
            $fid  = file_get_contents($this->path.'.fid');


            if($file = \App\Models\FileUpload::find($fid)){
                if($fileCl = \App\Models\FileCloud::find($file->cloud_id))
                    if(file_exists($fileCl->file_path))
                        return file_get_contents($fileCl->file_path);
//            return $file->file_path;
            }
        }
//        return '';
        // Replace this with a call to your API
        return @file_get_contents($this->path);
    }

    public function delete()
    {

        ol3("Delete1 $this->path");
//        die("DELETE.....xxx");

        if(is_file($this->path)){
            $fid = intval(file_get_contents($this->path.'.fid'));
            \App\Models\FileUpload::find($fid)?->delete();
        }
        unlink($this->path);
//        parent::delete(); // TODO: Change the autogenerated stub
    }

    function getSize() {
        // Replace this with a call to your API
//        return 1;
        if(file_exists($this->path.'.fid') && filesize($this->path.'.fid') < 20) {
            $fid = file_get_contents($this->path.'.fid');
            if ($file = \App\Models\FileUpload::find($fid)) {
                return $file->file_size;
            }
        }
//        return 0;
        return @filesize($this->path);
    }
}

//class RemoteDirectory extends \Sabre\DAV\Collection

class RemoteDirectory extends \Sabre\DAV\FS\Directory
{
    protected $path;
    protected $userId;

    function __construct($path, $uid = 0) {
//        ol3("__construct Of $path");
        $sid = \App\Models\SiteMng::getSiteId();
        $path = trim($path);
//        echo "<br/>\n PATHx = $path";
        $this->userId = $uid;
        if($path == '/' || !$path)
            $this->path = "/share/dav/siteid_$sid/$uid";
        else
        {
            //$this->path = "/share/dav/$uid" . $path;
            $this->path .=  $path;
        }
    }

    public function delete()
    {
        ol3("Delete1");
//        die("DELETE.....xxx1");

        foreach ($this->getChildren() as $child) {
            $child->delete();
        }

        $fileFid = $this->path . '.id';
        if(file_exists($fileFid) && filesize($fileFid) < 20){
            $fid = file_get_contents($fileFid);
            \App\Models\FolderFile::find($fid)?->delete();
        }
        else{
            if(is_file($this->path)){
                $fid = intval(file_get_contents($this->path.'.fid'));
                \App\Models\FileUpload::find($fid)?->delete();
            }
        }

        if(file_exists($this->path))
            rmdir($this->path);
    }

    function getName() {
        return basename($this->path);
    }

    public function createFile($name, $data = null)
    {

//        $datax = file_get_contents('php://input');
//        ol3("CreateFile11 size12345 = " . strlen($datax) ." | ". serialize(error_get_last()));


        ol3("----------- CreateFile0 $this->path/$name , " . gettype($data) );
        ol3('Resource type: ' . get_resource_type($data));
        $mt = stream_get_meta_data(($data));
        ol3('Resource type2: ' . serialize($mt));


        $fileId = @file_get_contents("$this->path/$name.fid");
        //neu la file Cu, thi la Update noi dung:
        if ($fileId && $fileOld = \App\Models\FileUpload::find($fileId)) {
            ol3('-- CreateFile old file1');
            $idCl = $fileOld->cloud_id;
            if ($fileCl = \App\Models\FileCloud::find($idCl)) {
                if (file_exists($fileCl->file_path)) {
                    ol3('-- CreateFile old file2');
                    file_put_contents($fileCl->file_path, $data);
                    ol3('-- CreateFile End ...');
                    return;
                }
            }
        }

        ol3("-----CreateFile0 " . __LINE__);

//        sleep(2);
//        $input = file_get_contents('php://input');
//        ol3("CreateFile1111 $name, size = " . strlen($input));

        //        $newPath = $this->path.'/'.$name;
//        die("PATH = " .  );


        $fileUpDone = $this->path ."/". $name;
        //Phải touch file này nếu ko Window upload sẽ báo lỗi, vì sau khi up ko thấy file real
//        touch($fileUpDone);

        $upDir = ini_get('upload_tmp_dir');
        if(!$upDir)
            $upDir =  sys_get_temp_dir();

        ol3("-----CreateFile01 " . __LINE__);

//        $fileUpDone = $upDir . '/upload_dav_' .$this->userId."-". microtime(1);
//        $fileUpDone = '/share/upload_dav_' . microtime(1);
//        if(@strlen($data))
//            $byte = file_put_contents($fileUpDone, $data);

//        ol3("CreateFile12 $fileUpDone / $byte / " . error_get_last());
        ol3("CreateFile1 $name, size2 = ");

        //Neu
        if(!file_exists($fileUpDone)){
            ol3(" Put streem now: $fileUpDone");
            file_put_contents($fileUpDone, $data);
            return;
        }

        ol3("CreateFile2 $name , size");
//        die($fileUpDone . ' Size: ' . filesize($fileUpDone));

        $folderID = 0;
        if(file_exists($this->path . '.id'))
            $folderID = intval(file_get_contents($this->path . '.id'));
        ol3("CreateFile21 $name");
        $std = new stdClass();
        $std->file_name = $name;
        $std->file_size = filesize($fileUpDone);
//        $std->file_size = 1;
        $std->file_name_upload_tool = $fileUpDone;
        $std->folder_id = $folderID;
        $std->user_id = $this->userId;
        $ret = \App\Http\ControllerApi\FileUploadControllerApi::uploadStatic($std);
//        if($ret->code == 1){
//            die("DONE!");
//        }
        ol3("CreateFile22 $name " );

        ol3("CreateFile23  $name "  . serialize($ret));

        $data = $ret->getData(true) ?? '';
        $code = $data['code'] ?? '';

        ol3("CreateFile24 $name");

        if($code != 1)
        {
            ol3("*** Errror: CreateFile25 $name");
//            loi("Error: Can not upload");
        }

//        if(file_exists($fileUpDone))
//            unlink($fileUpDone);
//        clearstatcache(true, $fileUpDone);

        ol3("++++ END CreateFile: $name");
    }

    public function createDirectory($name)
    {
        $fidPath = $this->path . '.id';
        $folderId = 0;
        if(file_exists($fidPath))
            $folderId = intval(file_get_contents($fidPath));

        $foldNew = new \App\Models\FolderFile();
        $foldNew->parent_id = 0;
        if(\App\Models\FolderFile::find($folderId)){
            $foldNew->parent_id = $folderId;
        }
        $foldNew->user_id = $this->userId;
        $foldNew->name = $name;

        if($foldNew->save()){
            file_put_contents($this->path . '/' . $name . '.id', $foldNew->id);
        }

        $newPath = $this->path.'/'.$name;
//        die("xxxx $newPath");
        mkdir($newPath);
        clearstatcache(true, $newPath);
    }

    //Các file upload từ window explore, sẽ là dạng raw file, chưa được up vào Cloud
    //ở đây sẽ up file này lên Cloud
    function uploadFileNewToCloudIfRawFile($filePath)
    {
        ol3(" uploadFileNewToCloudIfRawFile RETURN ");
        return;
        $ret = null;
        try {

            ol3(" uploadFileNewToCloudIfRawFile : $filePath");
            $folderID = @file_get_contents(dirname($filePath) . '.id');
            if(!$folderID)
                $folderID = 0;

            ol3(" uploadFileNewToCloudIfRawFile1 : $filePath");

            if(is_file($filePath)){
                ol3(" uploadFileNewToCloudIfRawFile2 : $filePath");
                $name = basename($filePath);
                $std = new stdClass();
                $std->file_name = $name;
                $std->file_size = filesize($filePath);
    //        $std->file_size = 1;
                $std->file_name_upload_tool = $filePath;
                $std->folder_id = $folderID;
                $std->user_id = $this->userId;

                ol3(" uploadFileNewToCloudIfRawFile21 : ". serialize($std));

                $ret = \App\Http\ControllerApi\FileUploadControllerApi::uploadStatic($std, 1);
                $ret = $ret->toArray();

//                dump($ret);
                ol3(" uploadFileNewToCloudIfRawFile3 : $filePath, ". serialize($ret));
                file_put_contents($filePath . '.fid', $ret['id'] ?? "-1");
                ol3("Upload file $filePath to Cloud: " . ($ret->id ?? ' not id ?'));

            }
        }
        catch (Exception $e){
            ol3("*** Error uploadFileNewToCloudIfRawFile: " . $e->getMessage());
        }
        return $ret;
    }

    function getChildren() {

        ol3("getChildren Of $this->path");
//        $this->path = str_replace('//', '/', $this->path);
//        echo "<br/>\n GetChild Of $this->path";
        $uid = $this->userId;
        $path = $this->path;

//        if(0)
        {
            $foldId = 0;

//            $path = "/share/dav/$uid".$path;
            if(file_exists($path . '.id'))
                $foldId = file_get_contents($path . '.id');

//            echo "<br/>\n Fod = $foldId";

            if(!file_exists($path))
                mkdir($path, 0777, true);
    //        die();
            $pathThis = $path;

            //Xoa tat ca cac folder hien tai:
            if(str_contains($pathThis, '/share/dav'))
                if(!str_contains($pathThis, '..')){
//                    exec("rm -rf $pathThis/*");
                }

            $fold = new \App\Models\FolderFile();
            $fold->id = $foldId;
            $mm = $fold->getChildren($uid);

//            dump($mm);
//            die();

            //Tạo các folder và file bên trong thư mục $this->path
            foreach ($mm AS $obj){
                if($obj->isFile){
//                    file_put_contents($pathThis . '/' . $obj->name, '');
                    file_put_contents($pathThis . '/' . $obj->name . '.fid', $obj->id);
                }
                else {
                    $fold = $pathThis . '/' . $obj->name;
                    if(!file_exists($fold))
                        mkdir($fold, 0777, true);
                    file_put_contents($fold . '.id', $obj->id);
                }
            }
        }


        // Replace this with a call to your API
        $children = [];
        foreach (scandir($path) as $file) {

            if(str_ends_with($file, '.id'))
                continue;
            if(str_ends_with($file, '.fid'))
                continue;

            $filePath = $path . '/' . $file;


            if(is_file($filePath) && filesize($filePath) > 20){
                ol3("New file Upload: $filePath");
                $this->uploadFileNewToCloudIfRawFile($filePath);
                continue;
            }

            if ($file === '.' || $file === '..') continue;
            $children[] = is_dir($path . '/' . $file)
                ? new RemoteDirectory($path . '/' . $file)
                : new RemoteFile($path . '/' . $file);
        }
        return $children;
    }

    function childExists($name) {
        ol3(" -------------- childExists Of $this->path/$name, size = " . @filesize("$this->path/$name"));

        $this->uploadFileNewToCloudIfRawFile($this->path. '/' . $name);
        // Replace this with a call to your API
        return file_exists($this->path . '/' . $name);
    }

    public function getChild0($name)
    {
        $path = $this->path.'/'.$name;

        if (!file_exists($path)) {
            throw new DAV\Exception\NotFound('File with name '.$path.' could not be located');
        }
        if (is_dir($path)) {
            return new self($path);
        } else {
//            return new File($path);
            return new RemoteFile($path);
        }
    }

    //Ke thua lai parent, sua chut
    public function getChild4($name)
    {
        ol3(" -------------- getChild Of $this->path/$name");

        $path = $this->path.'/'.$name;
        if (!file_exists($path)) {
            throw new DAV\Exception\NotFound('File with name '.$path.' could not be located');
        }

        if (is_dir($path)) {
            return new self($path);
        } else {

            $this->uploadFileNewToCloudIfRawFile($path);

            return new RemoteFile($path);
        }
    }

    //Dua ham nay vao lai ko tạo duoc fold:
    function getChild22($name) {

        // Replace this with a call to your API
        $path = $this->path . '/' . $name;
        ol3("getChild path = $path");
        if(!file_exists($path))
            return null;

        return is_dir($path)
            ? new RemoteDirectory($path, $this->userId)
            : new RemoteFile($path);
    }
}
