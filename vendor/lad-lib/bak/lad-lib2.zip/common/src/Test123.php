<?php

namespace LadLib\Common;


class Test123 {

    public function test() {
        echo 'test';
    }

}

