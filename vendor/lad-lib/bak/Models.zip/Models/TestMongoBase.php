<?php

namespace App\Models;

use App\Http\Middleware\Authenticate;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cookie;

use LadLib\Common\Database\MongoDbBase;
use Laravel\Sanctum\HasApiTokens;

class TestMongoBase extends MongoDbBase
{

    var $test1;
    var $test2;

//    public function getDbName()
//    {
//        return 'cmsLADMultiSite';
//    }

    public function getTableName()
    {
        return "data_color";
    }

    public function test111()
    {
        // TODO: Implement test111() method.
    }
}
