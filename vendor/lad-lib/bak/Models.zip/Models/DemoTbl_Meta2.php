<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use LadLib\Common\Database\MetaOfTableInDb2;
use PhpOffice\PhpSpreadsheet\Writer\Ods\Meta;

class DemoTbl_Meta2 extends MetaOfTableInDb2
{

    //public $api_url = "http://localhost:9081/api/demo";
    protected static $api_url_main = "http://localhost:9081/api/demo";
    /**
     * @param $field
     * @return MetaOfTableInDb2
     */
    public function getHardCodeMetaObj($field){

        $objMeta = new MetaOfTableInDb2();

        //Riêng Data type của Field, Lấy ra các field datatype mặc định
        //Nếu có thay đổi sẽ SET bên dưới
        $objSetDefault = new MetaOfTableInDb2();
        $objSetDefault->setDefaultMetaTypeField($field);
        $objMeta->dataType = $objSetDefault->dataType;

        if($field == 'string2'){
            $objMeta->is_select = 'joinSl1';
        }
        if($field == 'tag_list_id'){
            $objMeta->join_api_field = 'name';
            $objMeta->join_func = 'joinTags';
            $objMeta->join_api = '/api/tags/search';
            $objMeta->dataType = DEF_DATA_TYPE_ARRAY_NUMBER;
        }
        if($field == 'user_id'){
            $objMeta->join_api_field = 'email';
            $objMeta->join_func = 'joinUserEmailUserId';
            $objMeta->join_api = '/api/user/search';
        }

        return $objMeta;
    }


}
