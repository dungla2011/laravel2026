<?php

namespace App\Models;

use App\Http\Middleware\Authenticate;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cookie;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasFactory, SoftDeletes;

    //Token phan quyen ko dung cai nay van chay: use HasApiTokens;

    protected $guarded = [];

    /**
     * @return User
     */
    public function getUserByTokenAccess(){
        //Token được gửi từ Header
        //Lấy Token từ DB, sau đó tìm ra userid,
        $tk1 = request()->bearerToken();
        //$tk1 = request()->header("token_user");
        //Lấy ra user với token nếu có
        $user = User::where("token_user", $tk1)->first();
        return $user;
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class, 'role_user', 'user_id', 'role_id');
    }


    public function checkPermission($keyCode)
    {
//        return false;
//        dump($keyCode);
        //Nếu là API
        if (request()->is('api/*')) {

            $user = $this->getUserByTokenAccess();
            if (!$user) {
                //Nếu ko có token, vẫn có thể dựa trên Web Url, check session
                //Muốn check session ở đây, thì trong RouteServiceProvider::boot() , với api phải đặt ->middleware('web')
                if ($user = auth()->user()) {
                } else {
                    return false;
                }
            }
        } //Nếu là Web
        else
            $user = auth()->user();

        if ($user instanceof User) ;

        if (!$user)
            return false;

        //1. Lấy ra các role của user
        $roles = $user->roles;
        foreach ($roles as $role) {
            if ($role instanceof Role) ;
            //2. Từng role, lấy ra list permission của role đó, so sánh
            if ($role->permissions->contains('route_name_code', $keyCode)) {
                return true;
            }
//            dump($role->permissions);
        }
        return false;
    }

}
