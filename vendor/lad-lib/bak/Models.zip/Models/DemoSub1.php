<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DemoSub1 extends ModelGlxBase
{
    use HasFactory;
    protected $guarded = [];
}
