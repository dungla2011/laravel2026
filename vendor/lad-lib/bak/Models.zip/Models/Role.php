<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class Role extends ModelGlxBase
{
    use HasFactory, SoftDeletes;
    protected $guarded = [];

    public function permissions(){
//        $obj = new Permission();
//        $obj->setPrimaryKey('key_code');
        $ret =  $this->belongsToMany(Permission::class,
            'permission_role', 'role_id', 'permission_id', 'id', 'route_name_code')->withTimestamps();
//        $obj->setPrimaryKey('id');
        return $ret;
    }
}
