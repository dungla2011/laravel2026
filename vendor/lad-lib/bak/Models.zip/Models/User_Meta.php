<?php

namespace App\Models;

use App\Http\Middleware\Authenticate;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cookie;
use LadLib\Common\Database\MetaOfTableInDb;
use Laravel\Sanctum\HasApiTokens;

class User_Meta extends MetaOfTableInDb
{
    //public $api_url = "http://localhost:9081/api/user";
    protected static $api_url_main = "http://localhost:9081/api/user";
}
