<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DemoTbl extends ModelGlxBase
{
    use HasFactory, SoftDeletes;

    protected $guarded = [];

    public function sub1(){
        return $this->hasMany(DemoSub1::class , 'demo_id');
    }

    public function tags(){
        return $this->belongsToMany(TagDemo::class , 'tag_id_and_demo_id', 'demo_id', 'tag_id')->withTimestamps();
    }



}
