<?php

namespace LadLib\Common\Database;


trait Test1
{
    function abc(){

    }
}
