<?php

namespace LadLib\Common\Database;


trait TraitBase{



}
