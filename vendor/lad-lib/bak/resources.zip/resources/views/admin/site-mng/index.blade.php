@extends("layouts.adm")

@section("title")
    <title> INDEX Demo </title>
@endsection

@section('header')
    @include('parts.header-all')
@endsection

@section("content")
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Demo</a></li>
                            <li class="breadcrumb-item active">Dashboard v1</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">

                <div class="row">

                    <div class="col-md-12">
                        <a href="{{route('admin.site-mng.create')}}" class="btn btn-success float-right m-2"> ADD </a>
                    </div>
                    <div class="col-md-12">
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col"> ID </th>
                                @for($i = 1; $i<=6; $i++)
                                <th> Domain {{$i}}</th>
                                @endfor
                                <th> Action </th>

                            </tr>
                            </thead>
                            <tbody>

                                @foreach($data AS $item)

                                    <tr>
                                        <th> {{$item->id }} </th>
                                        @for($i = 1; $i<=6; $i++)
                                            <?php  $val = "domain".$i  ?>
                                        <th> {{$item->$val }} </th>
                                        @endfor
                                        <td>
                                            <a href="{{route("admin.site-mng.edit", ['id'=>$item->id])}}" class="btn btn-default"> Edit </a>
                                            <a href="{{route("admin.site-mng.delete", ['id'=>$item->id])}}" class="btn btn-danger"> Delete </a>
                                        </td>

                                    </tr>

                                @endforeach
                            </tbody>

                        </table>



                    </div>

                    <div class="col-md-12">
                        {{ $data->links() }}
                    </div>
                </div>


            </div>
        </div>
        <!-- /.content -->
    </div>
@endsection
