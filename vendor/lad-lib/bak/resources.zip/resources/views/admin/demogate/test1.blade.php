@extends("layouts.adm")

@section("title")
    <title> Test 1 - gate </title>
@endsection

@section("content")

    @include("admin.demogate.common_gate")

@endsection
