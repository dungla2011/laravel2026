@extends("layouts.adm")

@section("title")
    <title> Demo gate </title>
@endsection

@section('header')
    @include('parts.header-all')
@endsection

@section("content")

    @include("admin.demogate.common_gate")

@endsection
