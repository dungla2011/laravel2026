<?php
/**
 * Lấy toàn bộ Meta của 1 bảng ra, và cho phép edit các meta data đó
 */

use LadLib\Common\Database\MetaClassCommon;

use Illuminate\Support\Str;


?>
@extends("layouts.adm")

@section("title")
    <title> DbPermission </title>
@endsection

@section('header')
    @include('parts.header-all')
@endsection

@section('css')
    <link rel="stylesheet" href="/vendor/div_table2/div_table2.css">
@endsection

@section('js')
    <script src="/vendor/div_table2/div_table2.js"></script>
    <script src="/admins/meta-data-table/meta-data-table.js"></script>
@endsection

@section("content")

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">DbPermission</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Admin</a></li>
                            <li class="breadcrumb-item active">Dashboard v1</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php

                //
                $connectionDb = \Illuminate\Support\Facades\DB::getPdo();

                if (!$connectionDb)
                    die("NOT CON1");

                $mTable = \LadLib\Common\Database\DbHelper::getAllTableName($connectionDb, env("DB_DATABASE"));

                sort($mTable);

                $tableModelSelecting = request('table');
                if (!$tableModelSelecting)
                    $tableModelSelecting = $mTable[0];

                $urlCurrent = request()->getPathInfo();


                if(1){
                ?>
                <div class="row mb-2">
                    <div class="col-md-3">
                        <?php
                        echo "Chọn bảng <select class='form-control form-control-sm form-inline ' onchange='window.location.href=this.value'>";
                        echo "<option value='$urlCurrent'> - Select table - </option>";
                        foreach ($mTable AS $tblName) {

                            if (!\LadLib\Laravel\Database\DbHelperLaravel::getModelFromTableName($tblName)) {
                                continue;
                            }

                            $select = '';
                            if ($tableModelSelecting == $tblName)
                                $select = 'selected';
                            echo "<option $select value='$urlCurrent?table=$tblName'> $tblName </option>";
                        }
                        echo "</select>";
                        ?>
                    </div>
                    <div class="col-md-3">
                    </div>
                    <div class="col-md-3">
                    </div>
                    <div class="col-md-3">
                        <span class="btn btn-info float-right" id="save_all_form_button">SAVE</span>
                        <div style="clear: both"></div>
                    </div>
                </div>
                <?php
                }


                //Lấy ra API show lên
                $metaModelOfTable = \LadLib\Laravel\Database\DbHelperLaravel::getMetaObjFromTableName($tableModelSelecting);
                if (!$metaModelOfTable) {
                    echo "<br/>\n May be not found MetaClass of $tableModelSelecting";
                    goto _NEXT;
                }
                echo "API : " . $metaModelOfTable->getApiUrl() . " (Class: " . get_class($metaModelOfTable) . ")";

                /////////////////////
                $objMetaCommon = new MetaClassCommon();
                $mmFieldOfTable = [];
                if (!$tableModelSelecting)
                    goto _NEXT;

                $mmFieldOfTable = \LadLib\Common\Database\DbHelper::getTableColumns($connectionDb, $tableModelSelecting);

                //Lấy tên bảng meta, để truyền vào API update Meta bên dưới
                $tableNameMetaInfo = $tableModelSelecting . "_meta_info";
//                $objMetaCommon->setTableName($tableNameMetaInfo);


                //Lấy ra All Meta data của Bảng đã chọn
                $objMetaOfTable = new \LadLib\Common\Database\MetaOfTableInDb();
                $objMetaOfTable->setDbInfoGetMeta($tableModelSelecting, $connectionDb);
                $mmAllMetaDb = $objMetaOfTable->getMetaDataApi();

                //                echo "<pre> >>> " . __FILE__ . "(" . __LINE__ . ")<br/>";
                //                print_r($mmAllMetaDb);
                //                echo "</pre>";

                //                    return;
                //

                //                    $mmAllMetaDb = $objMetaCommon->getOrInitMetaTableIfNotHave($mmFieldOfTable);
                ?>
                <form action="" id="form_post_data" method="post">

                    <div class="divContainer" id="div_container_meta"
                         data-api-url="/api/common/save-meta-data?table_name=<?php echo $tableNameMetaInfo ?>">
                        <div class="divTable2" style=";border: 1px solid #000;">
                            <div class="divTable2Body">
                                <div class="divTable2Row">
                                    <?php
                                    //for($j = 0; $j < 4; $j++)

                                    //Show hàng Title TH
                                    foreach ($objMetaCommon AS $field=>$val) {

                                    if (!$objMetaCommon->isShowIndexField($field))
                                        continue;


                                    ?>
                                    <div class="divTable2Cell cellHeader" title="<?php echo $field ?>">
                                        <?php
                                        //echo $field;
                                        echo $objMetaCommon->getNameDescFromField($field);
                                        ?>
                                    </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                                <?php
                                $row = 0;
                                $t1 = microtime(1);

                                //Lấy ra từng Field của bảng, và show từng Hàng Meta tương ứng
                                foreach ($mmFieldOfTable AS $fieldInTable) {

                                    $objMetaOfFieldDb = $mmAllMetaDb[$fieldInTable];
                                    if ($objMetaOfFieldDb instanceof \LadLib\Common\Database\MetaOfTableInDb);

                                //for($row = 0; $row < 5; $row++){
                                ?>
                                <div class="divTable2Row">
                                    <?php
                                    //for($col = 0; $col < 4; $col++){
                                    $col = 0;
                                    //Mỗi fieldIntable, show ra hết các giá trị Meta thành 1 hàng
                                    foreach ($objMetaCommon AS $fieldMeta=>$tmp2){

                                        //Ẩn đi các CELL mà trường Meta không show index
                                        if (!$objMetaCommon->isShowIndexField($fieldMeta))
                                            continue;

                                        $disabledOK = null;

                                    ?>
                                    <div data-tablerow="<?php echo $row ?>" data-tablecol="<?php echo $col ?>"
                                         class="divTable2Cell">
                                        <?php
                                        $padHiden = null;
                                        $val = null;

                                        //Giá trị Edit:
                                        $val = $objMetaOfFieldDb->$fieldMeta;

                                        //Nếu field là hardcode (ko cho phép user sửa, như join_api) thì ko lấy từ db, mà lấy từ Class_Meta của Class
                                        if (MetaClassCommon::isHardCodeMetaField($fieldMeta)) {
                                            $val = $fieldInTable;
                                            $objMetaOfTable = \LadLib\Common\Database\DbHelper::getMetaObjFromTableName($tableModelSelecting);

                                            //Val sẽ chui vào, lấy từ trong hardcode ở ClassMeta của đối tượng
                                            $val = $objMetaOfTable->getHardCodeMetaObj($fieldInTable)?->$fieldMeta;
                                            //vd $val =  $objMetaOfTable->getHardCodeMetaObj('user_id')?->dataType;
                                            $disabledOK = 'disabled';
                                        }



                                        $displayInput = null;
                                        $id = $objMetaOfFieldDb->_id;
                                        if ($fieldMeta == '_id') {
                                            echo "<span class='spanField'> $objMetaOfFieldDb->_id </span>";
                                            $padHiden = 'hidden';
                                            $displayInput = ";display: none;";
                                        } elseif ($fieldMeta == 'sname') {
                                            $displayInput = ";display: none;";
                                            echo "<span class='spanField'> $objMetaOfFieldDb->sname </span>";
                                            $padHiden = 'hidden';
                                        } elseif ($fieldMeta == 'field') {
                                            $displayInput = ";display: none;";
                                            echo "<span class='spanField'>$fieldInTable</span>";
                                            $padHiden = 'hidden';
                                            $val = $fieldInTable;
                                        }
                                        if ($objMetaCommon->isStatusField($fieldMeta)) {
                                            if ($val == 0)
                                                $clsOnOff = "fa-toggle-off";
                                            else
                                                $clsOnOff = "fa-toggle-on";

                                            echo " <div class='text-center '> <i data-name='" . $fieldInTable . "[$fieldMeta]" . "' class='fa $clsOnOff change_status_item'></i> </div>";
                                            $displayInput = ";display: none;";
                                        } elseif ($funcMap = $objMetaCommon->isSelectField($fieldMeta)) {

                                            if ($disabledOK) {
                                                if (is_array($funcMap)) {
                                                    if ($val) {
                                                        echo "<span class='spanField'>" . $funcMap[$val] . "</span>";
                                                    }
                                                }
                                                //echo "ABC";
                                            } else
                                                if (is_array($funcMap)) {
                                                    $displayInput = ";display: none;";
                                                    $padHiden = 'hidden';
                                                    $padSelect = '';
                                                    $slOption = "<select $disabledOK name='" . $fieldInTable . "[$fieldMeta]" . "' dbp0e5455 title='field = $field' class='sl_option td_field_sfield td_field_$field' id='to_update_$id-$field' >";
                                                    $slOption .= "<option value=''> --- </option>";
                                                    $slOption .= "<option value='null' $padSelect> - not set - </option>";
                                                    $slVal = '';
                                                    foreach ($funcMap as $k => $v) {
                                                        $padSelect = "";
                                                        //sẽ là  ==, hay  === ?
                                                        //2021-08-25: đổi thành ==, cho ncbd layout
                                                        if ($val == $k) {
                                                            $padSelect = " selected ";
                                                            $slVal = $v;
                                                        }
                                                        $slOption .= "<option class='sl_option_item' $padSelect value='$k' dbp1 > $v </option>";
                                                    }
                                                    $slOption .= "</select>";
                                                    echo $slOption;
                                                    // $retAll .= " <div style='$cssCell' class='divTableCell ppp-0980iiu td_field_$sfield td_field_$field' > $slOption $linkToView </div>";
                                                    // clsDbTableMng::$retAllTableToExport .= " $slVal \t";
                                                    // $objRet->$field = $slVal;
                                                }
                                        }

                                        ?>
                                        <input <?php echo $disabledOK?>
                                               style="<?php echo $displayInput ?>" class="td_input"
                                               placeholder="<?php echo $fieldMeta ?>"
                                               <?php echo $padHiden ?> name="<?php echo $fieldInTable ?>[<?php echo $fieldMeta ?>]"
                                               data-field="<?php echo $fieldInTable ?>"
                                               data-meta-field="<?php echo $fieldMeta ?>"
                                               title="<?php echo "$fieldInTable | $fieldMeta | $val" ?>" type="text"
                                               value="<?php echo $val; ?>">
                                    </div>
                                    <?php
                                    $col++;
                                    }
                                    ?>
                                </div>
                                <?php
                                $row++;
                                }
                                $t2 = microtime(1);
                                //                                echo "<br/>\n DTIME = " . ($t2 - $t1);
                                ?>
                            </div>
                        </div>
                    </div>
                </form>

                <?php

                _NEXT:

                ?>
            </div>
        </section>
        <!-- /.content -->
    </div>
@endsection
