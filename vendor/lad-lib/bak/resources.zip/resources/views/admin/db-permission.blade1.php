<?php
use LadLib\Common\Database\MetaClassCommon;
?>
@extends("layouts.adm")

@section("title")
    <title> DbPermission </title>
@endsection

@section('header')
    @include('parts.header-all')
@endsection

@section('css')
    <link rel="stylesheet" href="/vendor/div_table2/div_table2.css">
@endsection

@section('js')
    <script src="/vendor/div_table2/div_table2.js"></script>
    <script src="/admins/meta-data-table/meta-data-table.js"></script>
@endsection

@section("content")

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">DbPermission</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Admin</a></li>
                            <li class="breadcrumb-item active">Dashboard v1</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php
                //
                $con = \Illuminate\Support\Facades\DB::getPdo();
                $mTable = \LadLib\Common\Database\DbHelper::getAllTableName($con, env("DB_DATABASE"));

                sort($mTable);

                $tableSelecting = request('table');
                if(!$tableSelecting)
                    $tableSelecting = $mTable[0];

                $urlCurrent = request()->getPathInfo();
                ?>
                <div class="row">
                    <div class="col-md-3">
                        <?php
                        echo "Select Table: <select class='form-control form-control-sm' onchange='window.location.href=this.value'>";
                        echo "<option value='$urlCurrent'> - Select table - </option>";
                        foreach ($mTable AS $tblName){
                            $select = '';
                            if($tableSelecting == $tblName)
                                $select = 'selected';
                            echo "<option $select value='$urlCurrent?table=$tblName'> $tblName </option>";
                        }
                        echo "</select>";
                        ?>
                    </div>
                </div>
                <?php
                $objMeta = new MetaClassCommon();
                $mmFieldObj = [];
                if($tableSelecting){
                    $mmFieldObj = \LadLib\Common\Database\DbHelper::getTableColumns($con, $tableSelecting);
                    $tableNameMetaInfo = $tableSelecting."_meta_info";
                    $objMeta->setTableName($tableNameMetaInfo);
                    $mmAllObjMeta = $objMeta->getOrInitMetaTableIfNotHave($mmFieldObj);
                ?>
                <form action="" id="form_post_data" method="post">
                    <div class="mb-3">
                        <span class="btn btn-info float-right" id="save_all_form_button">SAVE</span>
                        <div style="clear: both"></div>
                    </div>
                    <div class="divContainer" id="div_container_meta" data-api-url="/api/common/save-meta-data?table_name=<?php echo $tableNameMetaInfo ?>">
                        <div class="divTable2" style=";border: 1px solid #000;">
                            <div class="divTable2Body">
                                <div class="divTable2Row">
                                    <?php
                                    //for($j = 0; $j < 4; $j++)
                                    foreach ($objMeta AS $field=>$val) {
                                    ?>
                                    <div class="divTable2Cell cellHeader" title="<?php echo $field ?>">
                                        <?php
                                        //echo $field;
                                        echo $objMeta->getNameDescFromField($field);
                                        ?>
                                    </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                                <?php
                                $row = 0;
                                foreach ($mmFieldObj AS $fieldObj) {
                                //for($row = 0; $row < 5; $row++){
                                ?>
                                <div class="divTable2Row">
                                    <?php
                                    //for($col = 0; $col < 4; $col++){
                                    $col = 0;
                                    foreach ($objMeta AS $fieldMeta=>$tmp2){
                                    ?>
                                    <div data-tablerow="<?php echo $row ?>" data-tablecol="<?php echo $col ?>"
                                         class="divTable2Cell">
                                        <?php
                                        $padHiden = null;
                                        $val = null;

                                        //Nếu thấy field trong db, thì lấy VAL ra đưa vào Input
                                        foreach ($mmAllObjMeta AS $objMetaFound) {
                                            if ($objMetaFound->field == $fieldObj) {
                                                $val = $objMetaFound->$fieldMeta;
                                                break;
                                            }
                                        }

                                        $displayInput = null;
                                        $id = $objMetaFound->_id;
                                        if ($fieldMeta == '_id') {
                                            echo "<span class='spanField'> $objMetaFound->_id </span>";
                                            $padHiden = 'hidden';
                                            $displayInput = ";display: none;";
                                        } elseif ($fieldMeta == 'sname') {
                                            $displayInput = ";display: none;";
                                            echo "<span class='spanField'> $objMetaFound->sname </span>";
                                            $padHiden = 'hidden';
                                        } elseif ($fieldMeta == 'field') {
                                            $displayInput = ";display: none;";
                                            echo "<span class='spanField'>$fieldObj</span>";
                                            $padHiden = 'hidden';
                                            $val = $fieldObj;
                                        }
                                        if($objMetaFound->isStatusField($fieldMeta)){
                                            if($val == 0)
                                                $clsOnOff = "fa-toggle-off";
                                            else
                                                $clsOnOff = "fa-toggle-on";

                                            echo " <div class='text-center '> <i data-name='".$fieldObj."[$fieldMeta]"."' class='fa $clsOnOff change_status_item'></i> </div>";
                                            $displayInput = ";display: none;";
                                        }
                                        elseif($objMetaFound->isSelectField($fieldMeta)){
                                            $funcMap =  $objMetaFound->callJoinFunction('1');
                                            if (is_array($funcMap)) {
                                                $displayInput = ";display: none;";
                                                $padHiden = 'hidden';
                                                $padSelect = '';
                                                $slOption = "<select name='".$fieldObj."[$fieldMeta]"."' dbp0e5455 title='field = $field' class='sl_option td_field_sfield td_field_$field' id='to_update_$id-$field' >";
                                                $slOption .= "<option value=''> --SelectType-- </option>";
                                                $slOption .= "<option value='null' $padSelect> - not set - </option>";
                                                $slVal = '';
                                                foreach ($funcMap as $k => $v) {
                                                    $padSelect = "";
                                                    //sẽ là  ==, hay  === ?
                                                    //2021-08-25: đổi thành ==, cho ncbd layout
                                                    if ($val == $k){
                                                        $padSelect = " selected ";
                                                        $slVal = $v;
                                                    }
                                                    $slOption .= "<option class='sl_option_item' $padSelect value='$k' dbp1 > $v </option>";
                                                }
                                                $slOption .= "</select>";
                                                echo $slOption;
                                                // $retAll .= " <div style='$cssCell' class='divTableCell ppp-0980iiu td_field_$sfield td_field_$field' > $slOption $linkToView </div>";
                                                // clsDbTableMng::$retAllTableToExport .= " $slVal \t";
                                                // $objRet->$field = $slVal;
                                            }
                                        }

                                        ?>
                                        <input style="<?php echo  $displayInput ?>" class="td_input" placeholder="<?php echo $fieldMeta ?>"
                                               <?php echo $padHiden ?> name="<?php echo $fieldObj ?>[<?php echo $fieldMeta ?>]"
                                               data-field="<?php echo $fieldObj ?>"
                                               data-meta-field="<?php echo $fieldMeta ?>"
                                               title="<?php echo "$fieldObj / $fieldMeta" ?>" type="text"
                                               value="<?php echo $val; ?>">
                                    </div>
                                    <?php
                                    $col++;
                                    }
                                    ?>
                                </div>
                                <?php
                                $row++;
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </form>

                <?php
                }
                ?>
            </div>
        </section>
        <!-- /.content -->
    </div>
@endsection
