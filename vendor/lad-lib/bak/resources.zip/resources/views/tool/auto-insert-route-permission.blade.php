<a href="/admin"> Admin </a>
<hr>
<div class="content-wrapper">
    <div class="container">
        <h2>Auto insert permision
        </h2>
        <hr>
        Xem bảng permissions để thấy các quyền được tự động insert vào
        <hr>
        <br>
        <?php

        \App\Components\Helper1::createPermissionAutomatic();

        use Illuminate\Support\Facades\Route;
        $routeCollection = Route::getRoutes();

        //    return;
        $cc = 0;
        echo "<table border='1'>";
        echo "<tr>";
        echo "<td width=''><h4>HTTP Method</h4></td>";
        echo "<td width=''><h4>uri</h4></td>";
        echo "<td width=''><h4>getName</h4></td>";
        echo "<td width=''><h4>Corresponding Action</h4></td>";
        echo "<td width=''><h4>MidleWare</h4></td>";
        echo "<td width=''><h4>Prefix</h4></td>";
        echo "<td width=''><h4>Route desc</h4></td>";
        echo "<td width=''><h4>Route Group desc</h4></td>";

        echo "</tr>";
        foreach ($routeCollection as $value) {
            if ($value instanceof \Illuminate\Routing\Route) ;
            if ($value->uri() != 'login') {
                //            continue;
            }


            if (substr($value->getName(), 0, 6) == 'admin.'
                || substr($value->uri(), 0, 4) == 'api/'
            ){}
            else
                continue;

            $cc++;
            echo "<tr>";
            $uri0 = $value->uri();
            $uri = explode("/{", $uri0) [0];
            echo "<td> $cc . " . $value->methods()[0] . "</td>";
            echo "<td> <a href='/$uri' target='_blank'>$uri0 </a>" . "</td>";
            echo "<td>" . $value->getName() . "</td>";
            echo "<td>" . $value->getActionName() . "</td>";
            echo "<td>";
            foreach ($value->middleware() AS $md) {
                echo " $md <br/>\n";
            }
            echo "</td>";
            echo "<td>" . $value->getPrefix() . "</td>";

            if (isset($value->route_desc_))
                echo "<td>" . $value->route_desc_ . "</td>";
            else
                echo "<td></td>";
            if (isset($value->route_group_desc_))
                echo "<td>" . $value->route_group_desc_ . "</td>";
            else
                echo "<td></td>";

            echo "</tr>";

        }
        echo "</table>";

        ?>
    </div>
</div>
