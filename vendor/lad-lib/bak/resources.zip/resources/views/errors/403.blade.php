<h2> Chào {{ auth() && auth()->user() && auth()->user()->email ? auth()->user()->email : 'guest' }} </h2>
<h2>Bạn không có quyền truy cập vùng này! </h2>
