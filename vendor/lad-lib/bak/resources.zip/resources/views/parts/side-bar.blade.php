
<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/" class="brand-link">
        <img src="/adminlte/dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">AdminLTE 3</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->


        <br>
        <!-- SidebarSearch Form -->
        <div class="form-inline">
            <div class="input-group" data-widget="sidebar-search">
                <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-sidebar">
                        <i class="fas fa-search fa-fw"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
                     with font-awesome or any other icon font library -->
                <li class="nav-item menu-open">
                    <ul class="nav nav-treeview">


                        <li class="nav-item">
                            <a href="{{route("admin.demo.index")}}" class="nav-link">
                                <p>Demo table</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{route("admin.demo-api.index")}}" class="nav-link">
                                <p>Demo table - api - grid </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{route("admin.user.index")}}" class="nav-link">
                                <p>Users</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{route("admin.user-api.index")}}" class="nav-link">
                                <p>Users Api Grid</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{route("admin.role.index")}}" class="nav-link">

                                <p>Roles</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{route("admin.menu.index")}}" class="nav-link">

                                <p>Menu</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{route("admin.product.index")}}" class="nav-link">

                                <p>Product</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{route("tool.auto-insert-route-permission")}}" class="nav-link">
                                <p>Tool - Insert permission</p>
                            </a>
                        </li>




                        <li class="nav-item">
                            <a href="{{route("admin.site-mng.index")}}" class="nav-link">
                                <p>Site Managerment</p>
                            </a>
                        </li>


                        <li class="nav-item">
                            <a href="{{route("admin.db-permission")}}" class="nav-link">
                                <p>DB-Permission</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{route("admin.categories.index")}}" class="nav-link">

                                <p>Catetory</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{route("admin.demogate.index")}}" class="nav-link">

                                <p>Demo-Gate</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/logout" class="nav-link">

                                <p>Logout</p>
                                ({{ auth()->user() ? auth()->user()->email : '' }})
                            </a>
                        </li>

                    </ul>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
